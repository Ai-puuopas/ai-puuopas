# AI-puuopas

AI-puuopas v0.2 — Cloudflare Workers -pohja puutiedon, kuntoarvion ja AI-haun käyttöliittymälle.

## Kehitys

```bash
npm install
npm run dev
```

## Julkaisu

```bash
npm run deploy
```

## Rakenne

```text
src/worker.ts      Cloudflare Worker ja API-reitit
public/            Staattinen käyttöliittymä
wrangler.jsonc     Cloudflare-asetukset
```
